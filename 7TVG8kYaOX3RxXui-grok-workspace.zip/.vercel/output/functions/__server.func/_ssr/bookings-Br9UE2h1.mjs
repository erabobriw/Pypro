import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useI18n, o as useBookings, s as exploreSearch } from "./router-DiRjw4tB.mjs";
import { a as tourById, c as tx } from "./lang-CSnA3fdj.mjs";
import { r as formatKzt } from "./money-CtZ46Xec.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bookings-Br9UE2h1.js
var import_jsx_runtime = require_jsx_runtime();
function BookingsPage() {
	const { lang, t } = useI18n();
	const items = useBookings((state) => state.items);
	const ready = useBookings((state) => state.ready);
	const remove = useBookings((state) => state.remove);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-3xl px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-4xl text-fg",
				children: t.bookingMine
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-cream",
				children: t.bookingDemo
			}),
			!ready ? null : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 rounded-2xl border border-line bg-surface p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-cream",
					children: t.bookingEmpty
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/explore",
					search: exploreSearch(),
					className: "mt-4 inline-flex h-11 items-center text-copper",
					children: t.navTours
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 space-y-3",
				children: items.map((item) => {
					const tour = tourById(item.tourId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-2xl border border-line bg-surface p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [tour ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/tours/$tourId",
									params: { tourId: tour.id },
									className: "font-serif text-xl text-fg",
									children: tx(tour.title, lang)
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-fg",
									children: item.tourId
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm text-muted",
									children: [
										t.bookingWhen,
										": ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "tabular-nums text-cream",
											children: item.date
										}),
										" · ",
										item.people
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-copper/15 px-3 py-1 text-xs font-semibold text-copper",
									children: t.bookingStatus
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-3 grid grid-cols-3 gap-2 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: t.bookingPay
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "tabular-nums text-fg",
										children: formatKzt(item.pay)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: t.bookingFee
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "tabular-nums text-copper",
										children: formatKzt(item.fee)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: t.bookingPayout
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "tabular-nums text-fg",
										children: formatKzt(item.payout)
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => remove(item.id),
								className: "mt-4 h-11 text-sm text-muted",
								children: t.bookingCancel
							})
						]
					}, item.id);
				})
			})
		]
	});
}
//#endregion
export { BookingsPage as component };
