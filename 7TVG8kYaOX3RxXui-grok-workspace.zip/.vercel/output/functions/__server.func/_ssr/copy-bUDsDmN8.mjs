//#region node_modules/.nitro/vite/services/ssr/assets/copy-bUDsDmN8.js
function transportLabel(transport, t) {
	return {
		car: t.trCar,
		suv: t.trSuv,
		bus: t.trBus,
		horse: t.trHorse,
		mixed: t.trMixed,
		hike: t.trHike
	}[transport];
}
function difficultyLabel(difficulty, t) {
	if (difficulty === "easy") return t.diffEasy;
	if (difficulty === "hard") return t.diffHard;
	return t.diffModerate;
}
function dayLabel(days, lang) {
	if (lang === "en") return `${days} ${days === 1 ? "day" : "days"}`;
	if (lang === "kk") return `${days} күн`;
	const mod10 = days % 10;
	const mod100 = days % 100;
	if (mod10 === 1 && mod100 !== 11) return `${days} день`;
	if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return `${days} дня`;
	return `${days} дней`;
}
function langList(codes) {
	const names = {
		kk: "қаз",
		ru: "рус",
		en: "en"
	};
	return codes.map((code) => names[code]).join(" · ");
}
//#endregion
export { transportLabel as i, difficultyLabel as n, langList as r, dayLabel as t };
