import { C as require_jsx_runtime, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useI18n, i as Route$3, s as exploreSearch } from "./router-DiRjw4tB.mjs";
import { c as tx, i as regions, o as tours, r as regionById, t as guideById } from "./lang-CSnA3fdj.mjs";
import { r as toMapTour, t as MapCanvas } from "./map-tours-Vg3eSODR.mjs";
import { i as transportLabel, n as difficultyLabel } from "./copy-bUDsDmN8.mjs";
import { t as TourCard } from "./tour-card-D282xR_j.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/explore-CiGIlvwz.js
var import_jsx_runtime = require_jsx_runtime();
var transports = [
	"car",
	"suv",
	"bus",
	"horse",
	"mixed",
	"hike"
];
var difficulties = [
	"easy",
	"moderate",
	"hard"
];
function ExplorePage() {
	const search = Route$3.useSearch();
	const navigate = useNavigate();
	const { t, lang } = useI18n();
	const filtered = tours.filter((tour) => {
		if (search.region !== "all" && tour.regionId !== search.region) return false;
		if (search.transport !== "all" && tour.transport !== search.transport) return false;
		if (search.difficulty !== "all" && tour.difficulty !== search.difficulty) return false;
		const query = search.q.trim().toLowerCase();
		if (query) {
			const region = regionById(tour.regionId);
			const guide = guideById(tour.guideId);
			if (![
				tour.title.kk,
				tour.title.ru,
				tour.title.en,
				tour.summary.kk,
				tour.summary.ru,
				tour.summary.en,
				region.name.kk,
				region.name.ru,
				region.name.en,
				guide?.name ?? "",
				guide?.village.kk ?? "",
				guide?.village.ru ?? "",
				guide?.village.en ?? ""
			].join(" ").toLowerCase().includes(query)) return false;
		}
		return true;
	});
	const focusId = filtered.some((tour) => tour.id === search.focus) ? search.focus : null;
	function patch(partial) {
		navigate({
			to: "/explore",
			search: {
				...search,
				...partial
			},
			replace: true
		});
	}
	function showOnMap(id) {
		patch({ focus: id });
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		document.getElementById("tour-map")?.scrollIntoView({
			behavior: reduce ? "auto" : "smooth",
			block: "nearest"
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl text-fg",
				children: t.mapTitle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-2xl text-sm text-cream",
				children: t.mapNote
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-xs text-muted",
						children: [t.searchSubmit, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: search.q,
							onChange: (event) => patch({ q: event.target.value }),
							placeholder: t.searchPlaceholder,
							className: "mt-1 h-11 w-full rounded-xl border border-line bg-surface px-3 text-sm text-fg"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						label: t.filtersRegion,
						value: search.region,
						onChange: (region) => patch({
							region,
							focus: ""
						}),
						options: [{
							id: "all",
							name: t.filtersAll
						}, ...regions.map((region) => ({
							id: region.id,
							name: tx(region.name, lang)
						}))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						label: t.filtersTransport,
						value: search.transport,
						onChange: (transport) => patch({
							transport,
							focus: ""
						}),
						options: [{
							id: "all",
							name: t.filtersAll
						}, ...transports.map((id) => ({
							id,
							name: transportLabel(id, t)
						}))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						label: t.filtersDifficulty,
						value: search.difficulty,
						onChange: (difficulty) => patch({
							difficulty,
							focus: ""
						}),
						options: [{
							id: "all",
							name: t.filtersAll
						}, ...difficulties.map((id) => ({
							id,
							name: difficultyLabel(id, t)
						}))]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid items-start gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "order-2 lg:order-1",
					children: filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-line bg-surface p-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-cream",
							children: t.filtersEmpty
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => void navigate({
								to: "/explore",
								search: exploreSearch()
							}),
							className: "mt-4 h-11 rounded-full border border-line px-4 text-sm text-fg",
							children: t.filtersClear
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-4",
						children: filtered.map((tour) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: tour.id === focusId ? "rounded-2xl ring-2 ring-copper" : "",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TourCard, {
								tour,
								onMap: showOnMap
							})
						}, tour.id))
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "order-1 lg:sticky lg:top-28 lg:order-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapCanvas, {
						tours: (focusId ? filtered : filtered).map((tour) => toMapTour(tour, lang)),
						focusId,
						onFocus: (id) => patch({ focus: id }),
						loadingLabel: t.mapLoading,
						openLabel: t.mapOpen,
						kmLabel: t.km,
						note: t.mapNote
					})
				})]
			})
		]
	});
}
function Select({ label, value, onChange, options }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "text-xs text-muted",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
			value,
			onChange: (event) => onChange(event.target.value),
			className: "mt-1 h-11 w-full rounded-xl border border-line bg-surface px-3 text-sm text-fg",
			children: options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: option.id,
				children: option.name
			}, option.id))
		})]
	});
}
//#endregion
export { ExplorePage as component };
