import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as BadgeCheck } from "../_libs/lucide-react.mjs";
import { a as useI18n } from "./router-DiRjw4tB.mjs";
import { c as tx, n as guides, r as regionById, s as toursForGuide } from "./lang-CSnA3fdj.mjs";
import { r as langList } from "./copy-bUDsDmN8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/guides-BfiSDYHI.js
var import_jsx_runtime = require_jsx_runtime();
function GuidesPage() {
	const { lang, t } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-4xl text-fg",
				children: t.navGuides
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-2xl text-sm text-cream",
				children: t.demo
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-4 md:grid-cols-2",
				children: guides.map((guide) => {
					const region = regionById(guide.regionId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/guides/$guideId",
						params: { guideId: guide.id },
						className: "rounded-2xl border border-line bg-surface p-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-12 shrink-0 place-items-center rounded-full bg-surface-2 font-serif text-xl text-copper",
								children: guide.name.slice(0, 1)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
									className: "flex items-center gap-2 text-xl text-fg",
									children: [guide.name, guide.verified ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, {
										className: "size-4 text-moss",
										"aria-label": t.verified
									}) : null]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm text-muted",
									children: [
										tx(guide.village, lang),
										" · ",
										tx(region.name, lang)
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-cream",
									children: tx(guide.bio, lang)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 text-xs text-muted",
									children: [
										guide.years,
										" ",
										t.guideYears,
										" · ",
										t.guideLangs,
										": ",
										langList(guide.languages),
										" · ",
										toursForGuide(guide.id).length,
										" ",
										t.navTours.toLowerCase()
									]
								})
							] })]
						})
					}, guide.id);
				})
			})
		]
	});
}
//#endregion
export { GuidesPage as component };
