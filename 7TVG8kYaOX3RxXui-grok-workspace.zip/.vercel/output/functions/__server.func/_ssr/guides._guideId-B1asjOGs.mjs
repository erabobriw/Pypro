import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as BadgeCheck } from "../_libs/lucide-react.mjs";
import { a as useI18n, r as Route$1 } from "./router-DiRjw4tB.mjs";
import { c as tx, r as regionById, s as toursForGuide, t as guideById } from "./lang-CSnA3fdj.mjs";
import { r as toMapTour, t as MapCanvas } from "./map-tours-Vg3eSODR.mjs";
import { r as langList } from "./copy-bUDsDmN8.mjs";
import { t as TourCard } from "./tour-card-D282xR_j.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/guides._guideId-B1asjOGs.js
var import_jsx_runtime = require_jsx_runtime();
function GuidePage() {
	const { guideId } = Route$1.useParams();
	const { lang, t } = useI18n();
	const guide = guideById(guideId);
	if (!guide) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-3xl px-4 py-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-3xl text-fg",
			children: t.missingTitle
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/guides",
			className: "mt-4 inline-flex text-copper",
			children: t.navGuides
		})]
	});
	const region = regionById(guide.regionId);
	const mine = toursForGuide(guide.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/guides",
				className: "text-sm text-copper",
				children: t.navGuides
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex items-start gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-16 place-items-center rounded-full bg-surface font-serif text-2xl text-copper",
					children: guide.name.slice(0, 1)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "flex items-center gap-2 text-4xl text-fg",
						children: [guide.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, {
							className: "size-5 text-moss",
							"aria-label": t.verified
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: [
							tx(guide.village, lang),
							" · ",
							tx(region.name, lang),
							" · ",
							guide.years,
							" ",
							t.guideYears
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-cream",
						children: [
							t.guideLangs,
							": ",
							langList(guide.languages)
						]
					})
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 max-w-2xl text-base text-cream",
				children: tx(guide.bio, lang)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapCanvas, {
					compact: true,
					tours: mine.map((tour) => toMapTour(tour, lang)),
					focusId: null,
					onFocus: () => void 0,
					loadingLabel: t.mapLoading,
					openLabel: t.mapOpen,
					kmLabel: t.km,
					note: t.mapNote
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-8 text-2xl text-fg",
				children: t.guideTours
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid gap-4 md:grid-cols-2",
				children: mine.map((tour) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TourCard, { tour }, tour.id))
			})
		]
	});
}
//#endregion
export { GuidePage as component };
