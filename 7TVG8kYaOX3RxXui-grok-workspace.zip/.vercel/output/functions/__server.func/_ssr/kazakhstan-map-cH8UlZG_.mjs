import { i as __toESM } from "../_runtime.mjs";
import { p as require_react } from "../_libs/@react-leaflet/core+[...].mjs";
import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as routeKm } from "./map-tours-Vg3eSODR.mjs";
import { t as require_leaflet_src } from "../_libs/leaflet.mjs";
import { a as MapContainer, i as Marker, n as Popup, o as useMap, r as Polyline, t as TileLayer } from "../_libs/react-leaflet.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kazakhstan-map-cH8UlZG_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_leaflet_src = /* @__PURE__ */ __toESM(require_leaflet_src());
var KZ = [[40.8, 46.8], [55.2, 87.2]];
function pin(active) {
	return import_leaflet_src.default.divIcon({
		className: "",
		html: `<i class="gm-pin${active ? " is-on" : ""}"></i>`,
		iconSize: [16, 16],
		iconAnchor: [8, 8]
	});
}
function stopIcon() {
	return import_leaflet_src.default.divIcon({
		className: "",
		html: `<i class="gm-stop"></i>`,
		iconSize: [8, 8],
		iconAnchor: [4, 4]
	});
}
function lineStyle(transport, active) {
	if (transport === "hike") return {
		color: "#8eae86",
		weight: active ? 4 : 3,
		opacity: active ? .95 : .7,
		dashArray: "2 7"
	};
	if (transport === "horse" || transport === "mixed") return {
		color: "#c46a3a",
		weight: active ? 5 : 3,
		opacity: active ? .95 : .55,
		dashArray: "7 8"
	};
	return {
		color: "#c46a3a",
		weight: active ? 5 : 3,
		opacity: active ? .95 : .5
	};
}
function Frame({ focusId, tours }) {
	const map = useMap();
	(0, import_react.useEffect)(() => {
		const tour = focusId ? tours.find((item) => item.id === focusId) : void 0;
		const pts = tour ? tour.route.length > 0 ? tour.route : [tour.position] : KZ;
		if (pts.length === 1) map.setView(pts[0], 9, { animate: false });
		else map.fitBounds(pts, {
			padding: [28, 28],
			animate: false
		});
	}, [focusId, map]);
	(0, import_react.useEffect)(() => {
		const box = map.getContainer();
		const watcher = new ResizeObserver(() => map.invalidateSize());
		watcher.observe(box);
		return () => watcher.disconnect();
	}, [map]);
	return null;
}
function KazakhstanMap({ tours, focusId, onFocus, openLabel, kmLabel }) {
	const [bounds] = (0, import_react.useState)(() => {
		const tour = focusId ? tours.find((item) => item.id === focusId) : void 0;
		if (tour && tour.route.length > 1) return tour.route;
		return KZ;
	});
	const focused = tours.find((tour) => tour.id === focusId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(MapContainer, {
		bounds,
		scrollWheelZoom: false,
		className: "h-full w-full",
		zoomControl: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TileLayer, {
				attribution: "© OpenStreetMap © CARTO",
				url: "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
				focusId,
				tours
			}),
			tours.map((tour) => {
				const active = tour.id === focusId;
				if (!(active || focusId === null) || tour.route.length < 2) return null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Polyline, {
					positions: tour.route,
					pathOptions: lineStyle(tour.transport, active)
				}, `${tour.id}-line`);
			}),
			focused?.stops.map((stop) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Marker, {
				position: stop.position,
				icon: stopIcon(),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Popup, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-fg",
					children: stop.name
				}) })
			}, `${focused.id}-${stop.name}`)),
			tours.map((tour) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Marker, {
				position: tour.position,
				icon: pin(tour.id === focusId),
				eventHandlers: { click: () => onFocus(tour.id) },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Popup, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-serif text-base text-fg",
							children: tour.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm tabular-nums text-cream",
							children: [tour.priceLabel, tour.route.length > 1 ? ` · ${routeKm(tour.route)} ${kmLabel}` : ""]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/tours/$tourId",
							params: { tourId: tour.id },
							className: "text-sm text-copper",
							children: openLabel
						})
					]
				}) })
			}, tour.id))
		]
	});
}
//#endregion
export { KazakhstanMap };
