import { i as __toESM } from "../_runtime.mjs";
import { p as require_react } from "../_libs/@react-leaflet/core+[...].mjs";
import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as tx } from "./lang-CSnA3fdj.mjs";
import { r as formatKzt } from "./money-CtZ46Xec.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/map-tours-Vg3eSODR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function routeKm(route) {
	let km = 0;
	for (let i = 1; i < route.length; i++) km += haversine(route[i - 1], route[i]);
	return Math.round(km);
}
function haversine(a, b) {
	const r = 6371;
	const dLat = (b[0] - a[0]) * Math.PI / 180;
	const dLng = (b[1] - a[1]) * Math.PI / 180;
	const lat1 = a[0] * Math.PI / 180;
	const lat2 = b[0] * Math.PI / 180;
	const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
	return 2 * r * Math.asin(Math.min(1, Math.sqrt(h)));
}
function MapCanvas(props) {
	const [View, setView] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		import("./kazakhstan-map-cH8UlZG_.mjs").then((mod) => {
			if (live) setView(() => mod.KazakhstanMap);
		});
		return () => {
			live = false;
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		id: "tour-map",
		className: `map-frame relative overflow-hidden rounded-2xl border border-line ${props.compact ? "map-compact" : "map-stage"}`,
		children: [View ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(View, { ...props }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid h-full place-items-center bg-surface text-sm text-muted",
			children: props.loadingLabel
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "pointer-events-none absolute bottom-3 left-3 z-[1] max-w-[16rem] rounded-xl bg-bg/90 px-3 py-2 text-xs text-cream",
			children: props.note
		})]
	});
}
function toMapTour(tour, lang) {
	return {
		id: tour.id,
		title: tx(tour.title, lang),
		priceLabel: formatKzt(tour.priceKzt),
		transport: tour.transport,
		position: tour.position,
		route: tour.route,
		stops: tour.stops.map((stop) => ({
			name: tx(stop.name, lang),
			position: stop.position
		}))
	};
}
//#endregion
export { routeKm as n, toMapTour as r, MapCanvas as t };
