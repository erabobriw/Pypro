//#region node_modules/.nitro/vite/services/ssr/assets/money-CtZ46Xec.js
var FEE_RATE = .12;
var FEE_MIN = .1;
var FEE_MAX = .15;
function quote(priceKzt, people) {
	const pay = priceKzt * people;
	const fee = Math.round(pay * FEE_RATE);
	return {
		pay,
		fee,
		payout: pay - fee
	};
}
function formatKzt(value) {
	const rounded = Math.round(value);
	return `${rounded < 0 ? "-" : ""}${Math.abs(rounded).toString().replace(/\B(?=(\d{3})+(?!\d))/g, "\xA0")} ₸`;
}
//#endregion
export { quote as i, FEE_MIN as n, formatKzt as r, FEE_MAX as t };
