import { i as __toESM } from "../_runtime.mjs";
import { p as require_react } from "../_libs/@react-leaflet/core+[...].mjs";
import { C as require_jsx_runtime, S as useRouter, _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/search-BWZjzvMN.js
function exploreSearch(partial = {}) {
	return {
		q: "",
		region: "all",
		transport: "all",
		difficulty: "all",
		focus: "",
		...partial
	};
}
function readExploreSearch(search) {
	const text = (value) => typeof value === "string" ? value : "";
	return exploreSearch({
		q: text(search.q),
		region: text(search.region) || "all",
		transport: text(search.transport) || "all",
		difficulty: text(search.difficulty) || "all",
		focus: text(search.focus)
	});
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-DiRjw4tB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var KEY = "gm-bookings";
function read() {
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		if (!Array.isArray(parsed)) return [];
		return parsed.filter((item) => item && typeof item === "object" && "tourId" in item);
	} catch {
		return [];
	}
}
var useBookings = create((set, get) => ({
	ready: false,
	items: [],
	hydrate: () => {
		if (get().ready) return;
		set({
			items: read(),
			ready: true
		});
	},
	add: (booking) => {
		const items = [{
			...booking,
			id: crypto.randomUUID()
		}, ...get().items];
		localStorage.setItem(KEY, JSON.stringify(items));
		set({
			items,
			ready: true
		});
	},
	remove: (id) => {
		const items = get().items.filter((item) => item.id !== id);
		localStorage.setItem(KEY, JSON.stringify(items));
		set({ items });
	}
}));
var dictionaries = {
	kk: {
		brand: "GuideMatch",
		tag: "Жергілікті гидтер",
		navTours: "Турлар",
		navGuides: "Гидтер",
		navBookings: "Брондар",
		heroKicker: "Ауыл және тау",
		heroTitle: "Жергілікті гидті бір бронмен табыңыз",
		heroBody: "Алтай, Іле Алатауы, Шарын, Бурабай, Маңғыстау. Тексерілген гид, бағыт Қазақстан картасында, төлем тур біткенше ұсталады. Комиссия тек тур құнынан.",
		heroPrimary: "Картадан қарау",
		heroSecondary: "Гидтер",
		searchPlaceholder: "Шарын, Алтай, Бурабай…",
		searchSubmit: "Іздеу",
		demo: "Пилоттық каталог. Баға, гид және бағыт — демонстрация, нақты төлем алынбайды.",
		feeLabel: "Комиссия",
		feeValue: "10–15%",
		feeNote: "Тек аяқталған тур құнынан. Гидке абонент жоқ. Пилотта есеп 12%.",
		feeYouPay: "Турист төлейді",
		feePlatform: "Платформа",
		feeGuide: "Гидке кейін",
		exampleLow: "25 000 ₸ тур",
		exampleHigh: "80 000 ₸ тур",
		mapTitle: "Турлар Қазақстан картасында",
		mapNote: "Сызық — жол дәлізінің сызбасы, бұрылыс-бұрылыс навигация емес.",
		mapLoading: "Карта ашылып жатыр",
		mapOpen: "Турды ашу",
		mapRoad: "Көлік жолы",
		mapHorse: "Ат немесе аралас",
		mapFoot: "Жаяу соқпақ",
		km: "км",
		filtersRegion: "Аймақ",
		filtersTransport: "Көлік",
		filtersDifficulty: "Күрделілік",
		filtersAll: "Барлығы",
		filtersEmpty: "Бұл сүзгіге тур жоқ.",
		filtersClear: "Сүзгіні тазалау",
		diffEasy: "Жеңіл",
		diffModerate: "Орташа",
		diffHard: "Қиын",
		trCar: "Көлік",
		trSuv: "4×4",
		trBus: "Автобус",
		trHorse: "Ат",
		trMixed: "Көлік және жаяу",
		trHike: "Жаяу",
		perPerson: "адамға",
		day: "күн",
		days: "күн",
		verified: "Тексерілген",
		viewTour: "Тур",
		onMap: "Картада",
		featured: "Таңдаулы турлар",
		allTours: "Барлық тур",
		stepsKicker: "Қалай жұмыс істейді",
		stepsTitle: "Төрт қадам",
		step1: "Бағыт пен күн",
		step1t: "Аймақ, тіл және көлік түрін таңдайсыз.",
		step2: "Гидті салыстыру",
		step2t: "Профильде ауыл, тәжірибе және маршрут.",
		step3: "Бронь және төлем",
		step3t: "Ақша тур аяқталғанша эскроуда тұрады.",
		step4: "Комиссия",
		step4t: "GuideMatch 12% ұстайды, қалғаны гидке кетеді.",
		whoKicker: "Кімге",
		whoTitle: "Кім төлейді, кім табады",
		whoTravel: "Туристер",
		whoTravelt: "Экотуризм, треккинг, бір күндік шығу. Қазақстан және шетел.",
		whoGuide: "Гидтер",
		whoGuidet: "Ауыл және тау. Абонент жоқ — тек өткен турдан үлес.",
		whoPartner: "Серіктес",
		whoPartnert: "Шағын оператор жергілікті орындаушыны осы жерден табады.",
		pilotKicker: "Сұрау",
		pilotTitle: "Алдымен бір тау",
		pilotBody: "Бірінші маусым: бір аймақта 30 гид, қолмен тексеру, комиссияның жұмысын дәлелдеу.",
		pilotChip: "90 күн · 1 аймақ · 30 гид",
		bookingTitle: "Бронь",
		bookingDate: "Күн",
		bookingPeople: "Адам",
		bookingPay: "Төлем",
		bookingFee: "Комиссия 12%",
		bookingPayout: "Гидке турдан кейін",
		bookingHold: "Эскроуға ұстау",
		bookingHeld: "Төлем эскроуда",
		bookingDemo: "Демо: картадан ақша кетпейді. 24 сағат бұрын бас тарту тегін деп есептеледі.",
		bookingNeedDate: "Күнді таңдаңыз",
		bookingCancel: "Бас тарту",
		bookingEmpty: "Әзірге бронь жоқ.",
		bookingWhen: "Күні",
		bookingStatus: "Эскроу",
		bookingMine: "Менің брондарым",
		guideTours: "Турлары",
		guideYears: "жыл тәжірибе",
		guideLangs: "Тілдер",
		detailRoute: "Бағыт",
		detailMeeting: "Кездесу",
		detailIncludes: "Кіреді",
		detailAbout: "Гид",
		detailBack: "Турларға қайту",
		detailSchematic: "Картадағы сызық — Қазақстандағы жол дәлізінің сызбасы. Тау мен далада бұрылысты жергілікті гид біледі.",
		detailNoRoad: "Бұл тур жаяу. Картада соқпақ, тас жол емес.",
		missingTitle: "Тур табылмады",
		missingBody: "Каталогқа оралыңыз.",
		footerPhotos: "Фотосуреттер: Wikimedia Commons",
		footerLine: "Комиссия тур құнынан. Гид абонент төлемейді.",
		catalogCount: "пилоттық тур",
		guideCount: "гид",
		langNameKk: "Қаз",
		langNameRu: "Рус",
		langNameEn: "Eng"
	},
	ru: {
		brand: "GuideMatch",
		tag: "Местные гиды",
		navTours: "Туры",
		navGuides: "Гиды",
		navBookings: "Брони",
		heroKicker: "Сёла и горы",
		heroTitle: "Местный гид — одна бронь",
		heroBody: "Алтай, Заилийский Алатау, Чарын, Бурабай, Мангистау. Проверенный гид, маршрут на карте Казахстана, оплата держится до конца тура. Комиссия только из стоимости тура.",
		heroPrimary: "Смотреть на карте",
		heroSecondary: "Гиды",
		searchPlaceholder: "Чарын, Алтай, Бурабай…",
		searchSubmit: "Найти",
		demo: "Пилотный каталог. Цены, гиды и маршруты — демонстрация, деньги не списываются.",
		feeLabel: "Комиссия",
		feeValue: "10–15%",
		feeNote: "Только из стоимости завершённого тура. Абонентки для гида нет. В пилоте ставка 12%.",
		feeYouPay: "Турист платит",
		feePlatform: "Платформа",
		feeGuide: "Гиду после тура",
		exampleLow: "Тур 25 000 ₸",
		exampleHigh: "Тур 80 000 ₸",
		mapTitle: "Туры на карте Казахстана",
		mapNote: "Линия — схема коридора, не пошаговая навигация.",
		mapLoading: "Открываем карту",
		mapOpen: "Открыть тур",
		mapRoad: "Дорога",
		mapHorse: "Лошадь или смешанный",
		mapFoot: "Пешая тропа",
		km: "км",
		filtersRegion: "Регион",
		filtersTransport: "Транспорт",
		filtersDifficulty: "Сложность",
		filtersAll: "Все",
		filtersEmpty: "Под этот фильтр туров нет.",
		filtersClear: "Сбросить фильтр",
		diffEasy: "Легко",
		diffModerate: "Средне",
		diffHard: "Сложно",
		trCar: "Авто",
		trSuv: "4×4",
		trBus: "Автобус",
		trHorse: "Лошадь",
		trMixed: "Авто и пешком",
		trHike: "Пешком",
		perPerson: "с человека",
		day: "день",
		days: "дня",
		verified: "Проверен",
		viewTour: "Тур",
		onMap: "На карте",
		featured: "Из каталога",
		allTours: "Все туры",
		stepsKicker: "Как это работает",
		stepsTitle: "Четыре шага",
		step1: "Направление и дата",
		step1t: "Регион, язык и тип дороги.",
		step2: "Сравнить гида",
		step2t: "В профиле село, опыт и маршрут.",
		step3: "Бронь и оплата",
		step3t: "Деньги в эскроу до конца тура.",
		step4: "Комиссия",
		step4t: "GuideMatch удерживает 12%, остальное уходит гиду.",
		whoKicker: "Кому",
		whoTitle: "Кто платит, кто находит работу",
		whoTravel: "Туристы",
		whoTravelt: "Экотуризм, треккинг, выезд на день. Казахстан и гости.",
		whoGuide: "Гиды",
		whoGuidet: "Село и горы. Без абонентки — доля только с прошедшего тура.",
		whoPartner: "Партнёры",
		whoPartnert: "Небольшой оператор находит местного исполнителя здесь.",
		pilotKicker: "Запрос",
		pilotTitle: "Сначала одна гора",
		pilotBody: "Первый сезон: 30 гидов в одном районе, ручная проверка, доказательство комиссии.",
		pilotChip: "90 дней · 1 район · 30 гидов",
		bookingTitle: "Бронь",
		bookingDate: "Дата",
		bookingPeople: "Человек",
		bookingPay: "Оплата",
		bookingFee: "Комиссия 12%",
		bookingPayout: "Гиду после тура",
		bookingHold: "Удержать в эскроу",
		bookingHeld: "Оплата в эскроу",
		bookingDemo: "Демо: деньги с карты не списываются. Отмена за 24 часа считается бесплатной.",
		bookingNeedDate: "Выберите дату",
		bookingCancel: "Отменить",
		bookingEmpty: "Броней пока нет.",
		bookingWhen: "Дата",
		bookingStatus: "Эскроу",
		bookingMine: "Мои брони",
		guideTours: "Туры",
		guideYears: "лет опыта",
		guideLangs: "Языки",
		detailRoute: "Маршрут",
		detailMeeting: "Встреча",
		detailIncludes: "Входит",
		detailAbout: "Гид",
		detailBack: "К турам",
		detailSchematic: "Линия на карте — схема дорожного коридора по Казахстану. Повороты в горах и степи знает местный гид.",
		detailNoRoad: "Этот тур пеший. На карте тропа, не шоссе.",
		missingTitle: "Тур не найден",
		missingBody: "Вернитесь в каталог.",
		footerPhotos: "Фотографии: Wikimedia Commons",
		footerLine: "Комиссия из стоимости тура. Гид не платит абонентку.",
		catalogCount: "пилотных тура",
		guideCount: "гида",
		langNameKk: "Қаз",
		langNameRu: "Рус",
		langNameEn: "Eng"
	},
	en: {
		brand: "GuideMatch",
		tag: "Local guides",
		navTours: "Tours",
		navGuides: "Guides",
		navBookings: "Bookings",
		heroKicker: "Villages and mountains",
		heroTitle: "A local guide, in one booking",
		heroBody: "Altai, the Ile Alatau, Charyn, Burabay, Mangystau. A checked guide, the route on a map of Kazakhstan, payment held until the tour ends. The commission comes only from the tour price.",
		heroPrimary: "Open the map",
		heroSecondary: "Guides",
		searchPlaceholder: "Charyn, Altai, Burabay…",
		searchSubmit: "Search",
		demo: "Pilot catalog. Prices, guides, and routes are a demonstration — nothing is charged.",
		feeLabel: "Commission",
		feeValue: "10–15%",
		feeNote: "Taken only from a completed tour. No subscription for the guide. The pilot rate is 12%.",
		feeYouPay: "Traveler pays",
		feePlatform: "Platform",
		feeGuide: "Guide after the tour",
		exampleLow: "25,000 ₸ tour",
		exampleHigh: "80,000 ₸ tour",
		mapTitle: "Tours on the map of Kazakhstan",
		mapNote: "The line is a corridor sketch, not turn-by-turn navigation.",
		mapLoading: "Opening the map",
		mapOpen: "Open tour",
		mapRoad: "Road",
		mapHorse: "Horse or mixed",
		mapFoot: "Footpath",
		km: "km",
		filtersRegion: "Region",
		filtersTransport: "Transport",
		filtersDifficulty: "Difficulty",
		filtersAll: "All",
		filtersEmpty: "No tours match this filter.",
		filtersClear: "Clear filters",
		diffEasy: "Easy",
		diffModerate: "Moderate",
		diffHard: "Hard",
		trCar: "Car",
		trSuv: "4×4",
		trBus: "Bus",
		trHorse: "Horse",
		trMixed: "Car and hike",
		trHike: "On foot",
		perPerson: "per person",
		day: "day",
		days: "days",
		verified: "Verified",
		viewTour: "Tour",
		onMap: "On the map",
		featured: "From the catalog",
		allTours: "All tours",
		stepsKicker: "How it works",
		stepsTitle: "Four steps",
		step1: "Place and date",
		step1t: "Region, language, and how you travel.",
		step2: "Compare a guide",
		step2t: "Village, experience, and the route.",
		step3: "Book and pay",
		step3t: "The money stays in escrow until the tour ends.",
		step4: "Commission",
		step4t: "GuideMatch keeps 12%. The rest goes to the guide.",
		whoKicker: "Who",
		whoTitle: "Who pays, who gets the work",
		whoTravel: "Travelers",
		whoTravelt: "Ecotourism, trekking, a day out. Kazakhstan and visitors.",
		whoGuide: "Guides",
		whoGuidet: "Village and mountain. No subscription — a share only after the tour.",
		whoPartner: "Partners",
		whoPartnert: "A small operator finds a local guide here.",
		pilotKicker: "The ask",
		pilotTitle: "One mountain first",
		pilotBody: "First season: 30 guides in one district, checked by hand, to prove the commission.",
		pilotChip: "90 days · 1 district · 30 guides",
		bookingTitle: "Booking",
		bookingDate: "Date",
		bookingPeople: "People",
		bookingPay: "You pay",
		bookingFee: "12% commission",
		bookingPayout: "Guide after the tour",
		bookingHold: "Hold in escrow",
		bookingHeld: "Payment held",
		bookingDemo: "Demo: nothing is charged to a card. Cancel 24 hours ahead and the hold is free.",
		bookingNeedDate: "Choose a date",
		bookingCancel: "Cancel",
		bookingEmpty: "No bookings yet.",
		bookingWhen: "Date",
		bookingStatus: "Escrow",
		bookingMine: "My bookings",
		guideTours: "Tours",
		guideYears: "years guiding",
		guideLangs: "Languages",
		detailRoute: "Route",
		detailMeeting: "Meeting",
		detailIncludes: "Included",
		detailAbout: "Guide",
		detailBack: "Back to tours",
		detailSchematic: "The line is a sketch of the road corridor across Kazakhstan. In the mountains and the steppe, the local guide knows the turns.",
		detailNoRoad: "This tour is on foot. The map shows a trail, not a highway.",
		missingTitle: "Tour not found",
		missingBody: "Return to the catalog.",
		footerPhotos: "Photographs: Wikimedia Commons",
		footerLine: "Commission comes from the tour price. Guides pay no subscription.",
		catalogCount: "pilot tours",
		guideCount: "guides",
		langNameKk: "Қаз",
		langNameRu: "Рус",
		langNameEn: "Eng"
	}
};
var I18nContext = (0, import_react.createContext)(null);
function I18nProvider({ children }) {
	const [lang, setLangState] = (0, import_react.useState)("kk");
	(0, import_react.useEffect)(() => {
		const saved = localStorage.getItem("gm-lang");
		if (saved === "kk" || saved === "ru" || saved === "en") setLangState(saved);
	}, []);
	(0, import_react.useEffect)(() => {
		document.documentElement.lang = lang;
	}, [lang]);
	const setLang = (next) => {
		setLangState(next);
		localStorage.setItem("gm-lang", next);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(I18nContext.Provider, {
		value: {
			lang,
			setLang,
			t: dictionaries[lang]
		},
		children
	});
}
function useI18n() {
	const ctx = (0, import_react.useContext)(I18nContext);
	if (!ctx) throw new Error("useI18n outside provider");
	return ctx;
}
var langs = [
	"kk",
	"ru",
	"en"
];
function SiteHeader() {
	const { t, lang, setLang } = useI18n();
	const path = useRouterState({ select: (state) => state.location.pathname });
	const count = useBookings((state) => state.items.length);
	const names = {
		kk: t.langNameKk,
		ru: t.langNameRu,
		en: t.langNameEn
	};
	const links = [
		{
			to: "/explore",
			label: t.navTours,
			on: path.startsWith("/explore") || path.startsWith("/tours")
		},
		{
			to: "/guides",
			label: t.navGuides,
			on: path.startsWith("/guides")
		},
		{
			to: "/bookings",
			label: t.navBookings,
			on: path.startsWith("/bookings")
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-30 border-b border-line bg-bg/95 backdrop-blur",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-9 place-items-center rounded-xl bg-copper text-ink",
						"aria-hidden": true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
							viewBox: "0 0 24 24",
							className: "size-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
								d: "M12 3 L21 20 H3 Z",
								fill: "currentColor"
							})
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-semibold tracking-wide text-fg",
						children: t.brand
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden text-xs text-muted sm:block",
						children: t.tag
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-1 md:flex",
					children: links.map((link) => link.to === "/explore" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/explore",
						search: exploreSearch(),
						className: `rounded-full px-3 py-2 text-sm ${link.on ? "bg-surface-2 text-fg" : "text-cream"}`,
						children: link.label
					}, link.to) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: link.to,
						className: `rounded-full px-3 py-2 text-sm ${link.on ? "bg-surface-2 text-fg" : "text-cream"}`,
						children: [link.label, link.to === "/bookings" && count > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2 tabular-nums text-copper",
							children: count
						}) : null]
					}, link.to))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex rounded-full border border-line bg-surface p-1",
					children: langs.map((code) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setLang(code),
						className: `h-11 min-w-11 rounded-full px-3 text-xs font-semibold ${lang === code ? "bg-copper text-ink" : "text-muted"}`,
						"aria-pressed": lang === code,
						children: names[code]
					}, code))
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "flex gap-2 overflow-x-auto border-t border-line px-4 py-2 md:hidden",
			children: links.map((link) => link.to === "/explore" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/explore",
				search: exploreSearch(),
				className: `shrink-0 rounded-full px-3 py-2 text-sm ${link.on ? "bg-surface-2 text-fg" : "text-cream"}`,
				children: link.label
			}, link.to) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: link.to,
				className: `shrink-0 rounded-full px-3 py-2 text-sm ${link.on ? "bg-surface-2 text-fg" : "text-cream"}`,
				children: [link.label, link.to === "/bookings" && count > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ml-2 text-copper",
					children: count
				}) : null]
			}, link.to))
		})]
	});
}
function SiteFooter() {
	const { t } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "mt-16 border-t border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl flex-col gap-2 px-4 py-8 text-sm text-muted sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t.footerLine }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t.footerPhotos })]
		})
	});
}
function BookingHydrate() {
	const hydrate = useBookings((state) => state.hydrate);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	return null;
}
var styles_default = "/assets/styles-D5XOlwQ5.css";
var Route$6 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "GuideMatch" },
			{
				name: "description",
				content: "GuideMatch — жергілікті гидтер платформасы. Local guides in Kazakhstan’s villages and mountains. Commission from the tour price only."
			},
			{
				name: "theme-color",
				content: "#121614"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=Source+Serif+4:opsz,wght@8..60,500;8..60,600;8..60,700&display=swap"
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: Root
});
function Root() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "kk",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-bg text-fg antialiased",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(I18nProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingHydrate, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-h-screen flex-col",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
					]
				})] }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
var $$splitComponentImporter$5 = () => import("./routes-DF6gP2ir.mjs");
var Route$5 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./bookings-Br9UE2h1.mjs");
var Route$4 = createFileRoute("/bookings")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./explore-CiGIlvwz.mjs");
var Route$3 = createFileRoute("/explore")({
	validateSearch: (search) => readExploreSearch(search),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./guides-BfiSDYHI.mjs");
var Route$2 = createFileRoute("/guides")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./guides._guideId-B1asjOGs.mjs");
var Route$1 = createFileRoute("/guides/$guideId")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./tours._tourId-Ci8o437g.mjs");
var Route = createFileRoute("/tours/$tourId")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$5.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$6
});
var BookingsRoute = Route$4.update({
	id: "/bookings",
	path: "/bookings",
	getParentRoute: () => Route$6
});
var ExploreRoute = Route$3.update({
	id: "/explore",
	path: "/explore",
	getParentRoute: () => Route$6
});
var GuidesRoute = Route$2.update({
	id: "/guides",
	path: "/guides",
	getParentRoute: () => Route$6
});
var GuidesGuideIdRoute = Route$1.update({
	id: "/$guideId",
	path: "/$guideId",
	getParentRoute: () => GuidesRoute
});
var ToursTourIdRoute = Route.update({
	id: "/tours/$tourId",
	path: "/tours/$tourId",
	getParentRoute: () => Route$6
});
var GuidesRouteChildren = { GuidesGuideIdRoute };
var rootRouteChildren = {
	IndexRoute,
	BookingsRoute,
	ExploreRoute,
	GuidesRoute: GuidesRoute._addFileChildren(GuidesRouteChildren),
	ToursTourIdRoute
};
var routeTree = Route$6._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { useI18n as a, Route$3 as i, Route as n, useBookings as o, Route$1 as r, exploreSearch as s, router_exports as t };
