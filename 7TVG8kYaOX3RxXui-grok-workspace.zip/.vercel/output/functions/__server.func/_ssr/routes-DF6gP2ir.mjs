import { i as __toESM } from "../_runtime.mjs";
import { p as require_react } from "../_libs/@react-leaflet/core+[...].mjs";
import { C as require_jsx_runtime, b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useI18n, s as exploreSearch } from "./router-DiRjw4tB.mjs";
import { c as tx, i as regions, n as guides, o as tours } from "./lang-CSnA3fdj.mjs";
import { n as FEE_MIN, r as formatKzt, t as FEE_MAX } from "./money-CtZ46Xec.mjs";
import { r as toMapTour, t as MapCanvas } from "./map-tours-Vg3eSODR.mjs";
import { t as TourCard } from "./tour-card-D282xR_j.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DF6gP2ir.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var samples = [25e3, 8e4];
function FeeTable() {
	const { t } = useI18n();
	const labels = [t.exampleLow, t.exampleHigh];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-hidden rounded-2xl border border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full text-left text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
				className: "bg-surface-2 text-muted",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-3 font-medium",
						children: t.feeYouPay
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-3 font-medium",
						children: t.feePlatform
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-3 font-medium",
						children: t.feeGuide
					})
				] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: samples.map((price, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-t border-line bg-surface",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: "px-3 py-3 text-cream",
						children: [labels[index], /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block tabular-nums text-fg",
							children: formatKzt(price)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: "px-3 py-3 tabular-nums text-copper",
						children: [
							formatKzt(Math.round(price * FEE_MIN)),
							" – ",
							formatKzt(Math.round(price * FEE_MAX))
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: "px-3 py-3 tabular-nums text-fg",
						children: [
							formatKzt(price - Math.round(price * FEE_MAX)),
							" – ",
							formatKzt(price - Math.round(price * FEE_MIN))
						]
					})
				]
			}, price)) })]
		})
	});
}
function Home() {
	const { t, lang } = useI18n();
	const navigate = useNavigate();
	const [q, setQ] = (0, import_react.useState)("");
	const featured = tours.slice(0, 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid items-center gap-8 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-widest text-copper",
						children: t.heroKicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 text-4xl text-fg sm:text-5xl",
						children: t.heroTitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-base leading-relaxed text-cream",
						children: t.heroBody
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm text-muted",
						children: [
							tours.length,
							" ",
							t.navTours.toLowerCase(),
							" · ",
							guides.length,
							" ",
							t.navGuides.toLowerCase()
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-6 flex flex-col gap-2 sm:flex-row",
						onSubmit: (event) => {
							event.preventDefault();
							navigate({
								to: "/explore",
								search: exploreSearch({ q })
							});
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "sr-only",
								htmlFor: "q",
								children: t.searchSubmit
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "q",
								value: q,
								onChange: (event) => setQ(event.target.value),
								placeholder: t.searchPlaceholder,
								className: "h-12 flex-1 rounded-full border border-line bg-surface px-4 text-fg"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: "h-12 rounded-full bg-copper px-5 font-semibold text-ink",
								children: t.searchSubmit
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: regions.map((region) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/explore",
							search: exploreSearch({ region: region.id }),
							className: "rounded-full border border-line px-3 py-2 text-xs text-cream",
							children: tx(region.name, lang)
						}, region.id))
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/tours/altai.jpg",
					alt: t.heroTitle,
					className: "h-72 w-full rounded-2xl object-cover sm:h-96"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 rounded-2xl border border-line bg-surface px-4 py-3 text-sm text-cream",
				children: t.demo
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-12 grid gap-6 lg:grid-cols-[0.8fr_1.2fr] lg:items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-widest text-copper",
						children: t.feeLabel
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-serif text-5xl text-copper",
						children: t.feeValue
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-cream",
						children: t.feeNote
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeeTable, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-14",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 flex items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-3xl text-fg",
							children: t.mapTitle
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/explore",
							search: exploreSearch(),
							className: "text-sm text-copper",
							children: t.allTours
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapCanvas, {
						compact: true,
						tours: tours.map((tour) => toMapTour(tour, lang)),
						focusId: null,
						onFocus: (id) => {
							navigate({
								to: "/explore",
								search: exploreSearch({ focus: id })
							});
						},
						loadingLabel: t.mapLoading,
						openLabel: t.mapOpen,
						kmLabel: t.km,
						note: t.mapNote
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3 flex flex-wrap gap-4 text-xs text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-0.5 w-6 bg-copper" }), t.mapRoad]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-0.5 w-6 border-t border-dashed border-copper" }), t.mapHorse]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-0.5 w-6 border-t border-dotted border-moss" }), t.mapFoot]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-14",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-3xl text-fg",
					children: t.featured
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 grid gap-4 md:grid-cols-3",
					children: featured.map((tour) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TourCard, { tour }, tour.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-14",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-widest text-copper",
						children: t.stepsKicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 text-3xl text-fg",
						children: t.stepsTitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
						children: [
							[
								"01",
								t.step1,
								t.step1t
							],
							[
								"02",
								t.step2,
								t.step2t
							],
							[
								"03",
								t.step3,
								t.step3t
							],
							[
								"04",
								t.step4,
								t.step4t
							]
						].map(([num, title, body]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-2xl border border-line bg-surface p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-semibold text-copper",
									children: num
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-2 text-lg text-fg",
									children: title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-cream",
									children: body
								})
							]
						}, num))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-14",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-widest text-copper",
						children: t.whoKicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 text-3xl text-fg",
						children: t.whoTitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 grid gap-3 md:grid-cols-3",
						children: [
							[t.whoTravel, t.whoTravelt],
							[t.whoGuide, t.whoGuidet],
							[t.whoPartner, t.whoPartnert]
						].map(([title, body]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-2xl border border-line bg-surface p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg text-fg",
								children: title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-cream",
								children: body
							})]
						}, title))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-14 rounded-2xl border border-line bg-surface-2 p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-widest text-copper",
						children: t.pilotKicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 text-3xl text-fg",
						children: t.pilotTitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-2xl text-sm leading-relaxed text-cream",
						children: t.pilotBody
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 inline-flex rounded-full border border-copper px-3 py-2 text-sm text-copper",
						children: t.pilotChip
					})
				]
			})
		]
	});
}
//#endregion
export { Home as component };
