import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as BadgeCheck } from "../_libs/lucide-react.mjs";
import { a as useI18n } from "./router-DiRjw4tB.mjs";
import { c as tx, r as regionById, t as guideById } from "./lang-CSnA3fdj.mjs";
import { r as formatKzt } from "./money-CtZ46Xec.mjs";
import { n as routeKm } from "./map-tours-Vg3eSODR.mjs";
import { i as transportLabel, n as difficultyLabel, t as dayLabel } from "./copy-bUDsDmN8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tour-card-D282xR_j.js
var import_jsx_runtime = require_jsx_runtime();
function TourCard({ tour, onMap }) {
	const { lang, t } = useI18n();
	const guide = guideById(tour.guideId);
	const region = regionById(tour.regionId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex h-full flex-col overflow-hidden rounded-2xl border border-line bg-surface",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: tour.image,
			alt: tx(tour.title, lang),
			className: "h-44 w-full object-cover"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-wider text-copper",
						children: tx(region.name, lang)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-right text-sm font-semibold tabular-nums text-fg",
						children: [formatKzt(tour.priceKzt), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs font-normal text-muted",
							children: t.perPerson
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-2 text-xl text-fg",
					children: tx(tour.title, lang)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-cream",
					children: tx(tour.summary, lang)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-muted",
					children: [
						dayLabel(tour.days, lang),
						" · ",
						transportLabel(tour.transport, t),
						" · ",
						difficultyLabel(tour.difficulty, t),
						tour.route.length > 1 ? ` · ${routeKm(tour.route)} ${t.km}` : ""
					]
				}),
				guide ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 flex items-center gap-1 text-sm text-cream",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, {
						className: "size-4 text-moss",
						"aria-hidden": true
					}), guide.name]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/tours/$tourId",
						params: { tourId: tour.id },
						className: "inline-flex h-11 items-center rounded-full bg-copper px-4 text-sm font-semibold text-ink",
						children: t.viewTour
					}), onMap ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onMap(tour.id),
						className: "inline-flex h-11 items-center rounded-full border border-line px-4 text-sm text-fg",
						children: t.onMap
					}) : null]
				})
			]
		})]
	});
}
//#endregion
export { TourCard as t };
