import { i as __toESM } from "../_runtime.mjs";
import { p as require_react } from "../_libs/@react-leaflet/core+[...].mjs";
import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as BadgeCheck } from "../_libs/lucide-react.mjs";
import { a as useI18n, n as Route, o as useBookings, s as exploreSearch } from "./router-DiRjw4tB.mjs";
import { a as tourById, c as tx, r as regionById, t as guideById } from "./lang-CSnA3fdj.mjs";
import { i as quote, r as formatKzt } from "./money-CtZ46Xec.mjs";
import { n as routeKm, r as toMapTour, t as MapCanvas } from "./map-tours-Vg3eSODR.mjs";
import { i as transportLabel, n as difficultyLabel, t as dayLabel } from "./copy-bUDsDmN8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tours._tourId-Ci8o437g.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BookingPanel({ tour }) {
	const { t } = useI18n();
	const add = useBookings((state) => state.add);
	const [date, setDate] = (0, import_react.useState)("");
	const [people, setPeople] = (0, import_react.useState)(2);
	const [today, setToday] = (0, import_react.useState)("");
	const [held, setHeld] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setToday((/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
	}, []);
	const numbers = quote(tour.priceKzt, people);
	function hold() {
		if (!date) {
			setError(true);
			return;
		}
		add({
			tourId: tour.id,
			date,
			people,
			pay: numbers.pay,
			fee: numbers.fee,
			payout: numbers.payout
		});
		setHeld(true);
		setError(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl text-fg",
				children: t.bookingTitle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm text-muted",
					children: [t.bookingDate, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "date",
						min: today || void 0,
						value: date,
						onChange: (event) => {
							setDate(event.target.value);
							setError(false);
							setHeld(false);
						},
						className: "mt-1 h-11 w-full rounded-xl border border-line bg-bg px-3 text-fg"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm text-muted",
					children: [t.bookingPeople, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: people,
						onChange: (event) => {
							setPeople(Number(event.target.value));
							setHeld(false);
						},
						className: "mt-1 h-11 w-full rounded-xl border border-line bg-bg px-3 text-fg",
						children: Array.from({ length: 8 }, (_, index) => index + 1).map((count) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: count,
							children: count
						}, count))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-4 space-y-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t.bookingPay,
						value: formatKzt(numbers.pay)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t.bookingFee,
						value: formatKzt(numbers.fee)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t.bookingPayout,
						value: formatKzt(numbers.payout)
					})
				]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-copper",
				children: t.bookingNeedDate
			}) : null,
			held ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 rounded-xl bg-surface-2 px-3 py-3 text-sm text-cream",
				children: [
					t.bookingHeld,
					".",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/bookings",
						className: "text-copper",
						children: t.bookingMine
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: hold,
				className: "mt-4 h-12 w-full rounded-full bg-copper text-sm font-semibold text-ink",
				children: t.bookingHold
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs leading-relaxed text-muted",
				children: t.bookingDemo
			})
		]
	});
}
function Row({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3 border-b border-line pb-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "tabular-nums text-fg",
			children: value
		})]
	});
}
function TourPage() {
	const { tourId } = Route.useParams();
	const { lang, t } = useI18n();
	const tour = tourById(tourId);
	if (!tour) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-3xl px-4 py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl text-fg",
				children: t.missingTitle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-cream",
				children: t.missingBody
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/explore",
				search: exploreSearch(),
				className: "mt-6 inline-flex h-11 items-center text-copper",
				children: t.detailBack
			})
		]
	});
	const guide = guideById(tour.guideId);
	const region = regionById(tour.regionId);
	const road = tour.transport !== "hike";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/explore",
			search: exploreSearch({
				focus: tour.id,
				region: tour.regionId
			}),
			className: "text-sm text-copper",
			children: t.detailBack
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid gap-6 lg:grid-cols-[1.3fr_0.7fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold uppercase tracking-widest text-copper",
					children: tx(region.name, lang)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 text-4xl text-fg",
					children: tx(tour.title, lang)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-muted",
					children: [
						dayLabel(tour.days, lang),
						" · ",
						transportLabel(tour.transport, t),
						" · ",
						difficultyLabel(tour.difficulty, t),
						" ·",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums text-fg",
							children: formatKzt(tour.priceKzt)
						}),
						" ",
						t.perPerson,
						tour.route.length > 1 ? ` · ${routeKm(tour.route)} ${t.km}` : ""
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: tour.image,
					alt: tx(tour.title, lang),
					className: "mt-5 h-72 w-full rounded-2xl object-cover sm:h-96"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 text-base leading-relaxed text-cream",
					children: tx(tour.summary, lang)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-8 text-2xl text-fg",
					children: t.detailRoute
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-cream",
					children: road ? t.detailSchematic : t.detailNoRoad
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapCanvas, {
						tours: [toMapTour(tour, lang)],
						focusId: tour.id,
						onFocus: () => void 0,
						loadingLabel: t.mapLoading,
						openLabel: t.mapOpen,
						kmLabel: t.km,
						note: t.mapNote
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-4 space-y-2",
					children: tour.stops.map((stop, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3 text-sm text-cream",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums text-copper",
							children: String(index + 1).padStart(2, "0")
						}), tx(stop.name, lang)]
					}, tx(stop.name, lang)))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-8 text-2xl text-fg",
					children: t.detailMeeting
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-cream",
					children: tx(tour.meeting, lang)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-8 text-2xl text-fg",
					children: t.detailIncludes
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 space-y-1 text-sm text-cream",
					children: tour.includes.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: tx(item, lang) }, tx(item, lang)))
				}),
				guide ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/guides/$guideId",
					params: { guideId: guide.id },
					className: "mt-8 flex items-start gap-3 rounded-2xl border border-line bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-12 shrink-0 place-items-center rounded-full bg-surface-2 font-serif text-lg text-copper",
						children: guide.name.slice(0, 1)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1 text-fg",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, {
								className: "size-4 text-moss",
								"aria-hidden": true
							}),
							guide.name,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-moss",
								children: t.verified
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block text-sm text-cream",
						children: tx(guide.bio, lang)
					})] })]
				}) : null
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingPanel, { tour })]
		})]
	});
}
//#endregion
export { TourPage as component };
