//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-RAUg5Y6M.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/bookings",
			"/explore",
			"/guides",
			"/tours/$tourId"
		],
		preloads: [
			"/assets/index-Czy0om6R.js",
			"/assets/link-CbLTYCOY.js",
			"/assets/lazyRouteComponent-B056V5A1.js",
			"/assets/preload-helper-CtmL1FcF.js",
			"/assets/search-CWtqZS6V.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Czy0om6R.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-ux1xpplg.js",
			"/assets/map-tours-CeIe0drW.js",
			"/assets/lang-DR41SNOa.js",
			"/assets/money-DoR5PiQ4.js",
			"/assets/tour-card-WaZN2IMW.js"
		]
	},
	"/bookings": {
		filePath: "/workspace/src/routes/bookings.tsx",
		children: void 0,
		preloads: [
			"/assets/bookings-D0UVrU9X.js",
			"/assets/lang-DR41SNOa.js",
			"/assets/money-DoR5PiQ4.js"
		]
	},
	"/explore": {
		filePath: "/workspace/src/routes/explore.tsx",
		children: void 0,
		preloads: [
			"/assets/explore-BSEKZD0P.js",
			"/assets/copy-Cw-S0suG.js",
			"/assets/map-tours-CeIe0drW.js",
			"/assets/lang-DR41SNOa.js",
			"/assets/tour-card-WaZN2IMW.js"
		]
	},
	"/guides": {
		filePath: "/workspace/src/routes/guides.tsx",
		children: ["/guides/$guideId"],
		preloads: [
			"/assets/guides-DoFf0hha.js",
			"/assets/copy-Cw-S0suG.js",
			"/assets/lang-DR41SNOa.js"
		]
	},
	"/guides/$guideId": {
		filePath: "/workspace/src/routes/guides.$guideId.tsx",
		children: void 0,
		preloads: [
			"/assets/guides._guideId-BvW4VlYb.js",
			"/assets/map-tours-CeIe0drW.js",
			"/assets/tour-card-WaZN2IMW.js"
		]
	},
	"/tours/$tourId": {
		filePath: "/workspace/src/routes/tours.$tourId.tsx",
		children: void 0,
		preloads: [
			"/assets/tours._tourId-CJcpKxeY.js",
			"/assets/copy-Cw-S0suG.js",
			"/assets/map-tours-CeIe0drW.js",
			"/assets/lang-DR41SNOa.js",
			"/assets/money-DoR5PiQ4.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
