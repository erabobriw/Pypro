import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import type { Tour } from "@/data/catalog";
import { useBookings } from "@/lib/bookings";
import { useI18n } from "@/lib/i18n";
import { formatKzt, quote } from "@/lib/money";

export function BookingPanel({ tour }: { tour: Tour }) {
  const { t } = useI18n();
  const add = useBookings((state) => state.add);
  const [date, setDate] = useState("");
  const [people, setPeople] = useState(2);
  const [today, setToday] = useState("");
  const [held, setHeld] = useState(false);
  const [error, setError] = useState(false);

  useEffect(() => {
    setToday(new Date().toISOString().slice(0, 10));
  }, []);

  const numbers = quote(tour.priceKzt, people);

  function hold() {
    if (!date) {
      setError(true);
      return;
    }
    add({ tourId: tour.id, date, people, pay: numbers.pay, fee: numbers.fee, payout: numbers.payout });
    setHeld(true);
    setError(false);
  }

  return (
    <section className="rounded-2xl border border-line bg-surface p-4">
      <h2 className="text-2xl text-fg">{t.bookingTitle}</h2>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <label className="block text-sm text-muted">
          {t.bookingDate}
          <input
            type="date"
            min={today || undefined}
            value={date}
            onChange={(event) => {
              setDate(event.target.value);
              setError(false);
              setHeld(false);
            }}
            className="mt-1 h-11 w-full rounded-xl border border-line bg-bg px-3 text-fg"
          />
        </label>
        <label className="block text-sm text-muted">
          {t.bookingPeople}
          <select
            value={people}
            onChange={(event) => {
              setPeople(Number(event.target.value));
              setHeld(false);
            }}
            className="mt-1 h-11 w-full rounded-xl border border-line bg-bg px-3 text-fg"
          >
            {Array.from({ length: 8 }, (_, index) => index + 1).map((count) => (
              <option key={count} value={count}>
                {count}
              </option>
            ))}
          </select>
        </label>
      </div>
      <dl className="mt-4 space-y-2 text-sm">
        <Row label={t.bookingPay} value={formatKzt(numbers.pay)} />
        <Row label={t.bookingFee} value={formatKzt(numbers.fee)} />
        <Row label={t.bookingPayout} value={formatKzt(numbers.payout)} />
      </dl>
      {error ? <p className="mt-3 text-sm text-copper">{t.bookingNeedDate}</p> : null}
      {held ? (
        <p className="mt-4 rounded-xl bg-surface-2 px-3 py-3 text-sm text-cream">
          {t.bookingHeld}.{" "}
          <Link to="/bookings" className="text-copper">
            {t.bookingMine}
          </Link>
        </p>
      ) : (
        <button
          type="button"
          onClick={hold}
          className="mt-4 h-12 w-full rounded-full bg-copper text-sm font-semibold text-ink"
        >
          {t.bookingHold}
        </button>
      )}
      <p className="mt-3 text-xs leading-relaxed text-muted">{t.bookingDemo}</p>
    </section>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-line pb-2">
      <dt className="text-muted">{label}</dt>
      <dd className="tabular-nums text-fg">{value}</dd>
    </div>
  );
}
