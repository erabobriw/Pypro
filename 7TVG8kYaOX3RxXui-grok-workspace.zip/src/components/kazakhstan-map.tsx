import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { MapContainer, Marker, Polyline, Popup, TileLayer, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import type { Transport } from "@/data/catalog";
import { routeKm } from "@/lib/geo";

export type MapTour = {
  id: string;
  title: string;
  priceLabel: string;
  transport: Transport;
  position: [number, number];
  route: [number, number][];
  stops: { name: string; position: [number, number] }[];
};

export type MapCanvasProps = {
  tours: MapTour[];
  focusId: string | null;
  onFocus: (id: string) => void;
  compact?: boolean;
  loadingLabel: string;
  openLabel: string;
  kmLabel: string;
  note: string;
};

const KZ: [number, number][] = [
  [40.8, 46.8],
  [55.2, 87.2],
];

function pin(active: boolean) {
  return L.divIcon({
    className: "",
    html: `<i class="gm-pin${active ? " is-on" : ""}"></i>`,
    iconSize: [16, 16],
    iconAnchor: [8, 8],
  });
}

function stopIcon() {
  return L.divIcon({
    className: "",
    html: `<i class="gm-stop"></i>`,
    iconSize: [8, 8],
    iconAnchor: [4, 4],
  });
}

function lineStyle(transport: Transport, active: boolean) {
  if (transport === "hike") {
    return { color: "#8eae86", weight: active ? 4 : 3, opacity: active ? 0.95 : 0.7, dashArray: "2 7" };
  }
  if (transport === "horse" || transport === "mixed") {
    return { color: "#c46a3a", weight: active ? 5 : 3, opacity: active ? 0.95 : 0.55, dashArray: "7 8" };
  }
  return { color: "#c46a3a", weight: active ? 5 : 3, opacity: active ? 0.95 : 0.5 };
}

function Frame({ focusId, tours }: { focusId: string | null; tours: MapTour[] }) {
  const map = useMap();
  useEffect(() => {
    const tour = focusId ? tours.find((item) => item.id === focusId) : undefined;
    const pts = tour ? (tour.route.length > 0 ? tour.route : [tour.position]) : KZ;
    if (pts.length === 1) map.setView(pts[0], 9, { animate: false });
    else map.fitBounds(pts, { padding: [28, 28], animate: false });
    // Refit only when the selected tour changes, not on every parent render.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focusId, map]);

  useEffect(() => {
    const box = map.getContainer();
    const watcher = new ResizeObserver(() => map.invalidateSize());
    watcher.observe(box);
    return () => watcher.disconnect();
  }, [map]);

  return null;
}

export function KazakhstanMap({ tours, focusId, onFocus, openLabel, kmLabel }: MapCanvasProps) {
  const [bounds] = useState<[number, number][]>(() => {
    const tour = focusId ? tours.find((item) => item.id === focusId) : undefined;
    if (tour && tour.route.length > 1) return tour.route;
    return KZ;
  });

  const focused = tours.find((tour) => tour.id === focusId);

  return (
    <MapContainer
      bounds={bounds}
      scrollWheelZoom={false}
      className="h-full w-full"
      zoomControl
    >
      <TileLayer
        attribution='&copy; OpenStreetMap &copy; CARTO'
        url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
      />
      <Frame focusId={focusId} tours={tours} />
      {tours.map((tour) => {
        const active = tour.id === focusId;
        const showLine = active || focusId === null;
        if (!showLine || tour.route.length < 2) return null;
        return (
          <Polyline
            key={`${tour.id}-line`}
            positions={tour.route}
            pathOptions={lineStyle(tour.transport, active)}
          />
        );
      })}
      {focused?.stops.map((stop) => (
        <Marker key={`${focused.id}-${stop.name}`} position={stop.position} icon={stopIcon()}>
          <Popup>
            <span className="text-sm text-fg">{stop.name}</span>
          </Popup>
        </Marker>
      ))}
      {tours.map((tour) => (
        <Marker
          key={tour.id}
          position={tour.position}
          icon={pin(tour.id === focusId)}
          eventHandlers={{ click: () => onFocus(tour.id) }}
        >
          <Popup>
            <div className="space-y-1">
              <p className="font-serif text-base text-fg">{tour.title}</p>
              <p className="text-sm tabular-nums text-cream">
                {tour.priceLabel}
                {tour.route.length > 1 ? ` · ${routeKm(tour.route)} ${kmLabel}` : ""}
              </p>
              <Link to="/tours/$tourId" params={{ tourId: tour.id }} className="text-sm text-copper">
                {openLabel}
              </Link>
            </div>
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}
