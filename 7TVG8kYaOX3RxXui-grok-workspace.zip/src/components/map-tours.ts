import type { MapTour } from "@/components/kazakhstan-map";
import type { Tour } from "@/data/catalog";
import type { Lang } from "@/lib/lang";
import { tx } from "@/lib/lang";
import { formatKzt } from "@/lib/money";

export function toMapTour(tour: Tour, lang: Lang): MapTour {
  return {
    id: tour.id,
    title: tx(tour.title, lang),
    priceLabel: formatKzt(tour.priceKzt),
    transport: tour.transport,
    position: tour.position,
    route: tour.route,
    stops: tour.stops.map((stop) => ({ name: tx(stop.name, lang), position: stop.position })),
  };
}
